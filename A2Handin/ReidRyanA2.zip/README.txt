RyanReid
7678567
reidr3@myumanitoba.ca
A2 readme

*NOTE*
I have used lamda expersions throughout the assignment. These are only in java 1.7 or later. Java MUST be updated to the point where lamdas were introduced for it to work. Java 8 should be the version you use.

What works? Everything
Colours for the control handles might not be *quite* right - but there was nothing in the assignment dictating what they should be.
Rotate handle: Is on the "top" center of the object (top is relative to it's rotation i.e the original "top") colour is red
Resize handle: Is on the the bottom left of the object (Again, bottom left of the original) colour is green

System specs:
Windows 10 64-bit Academic version
CPU: i5-3570k
GPU: AMD RX 480 - newest crimson drivers
Java: Newest version of 1.8