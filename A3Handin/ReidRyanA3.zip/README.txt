System specs:
Windows 10 64bit
AMD RX 480 - Up to date drivers
Most up to date version of java

Q1: Finished! 
Additional feature: Wind 
Two sliders. On on the right hand side controls verticle wind. Pulling the slide up blows "up" same idea for the bottom slider right blows right. Left - left.
Wind has a stronger effect of bubbles/particles the longer they are on the screen(To prevent "stationary" items)

Q2: Not even close to done.
Camera angles are implemented but they are all pretty bad.

Robot is mostly there. Body, arms legs and a head. All are rectangles though. No levels of hierachy were added.
Robot moves across the screen. He does come back at the end but sometimes it takes a little bit...

Rotation: yikes.
Head rotates in a circle, but not around it's own center.
Arms rotate but they seem to rotate in a circle at a point below them.
Legs rotate: This are slightly closer. They rotate 45 degrees but from their center and "jump" back to 0 degrees after 45 so it's not a fluid motion.

I just didn't have time at all for this section. Couple other exams/assignments/work so I unfortunately could not put the time into getting it to work right. Sorry for the gross code you need to start marking.
Hierachy was going to be not to bad to finish doing. It rotates before calling the draw so the sub shapes should be able to rotate fairly easily if I had time to add them.